from typing import Final, Dict

from CalculatingUnit import CalculatingUnit
from FullAdder import FullAdder


class BinaryCalculator:
    MODE_ADDITION: Final[int] = 0

    def __init__(self, mode: int):
        if mode == self.MODE_ADDITION:
            self.calculating_unit: CalculatingUnit = FullAdder([12, 10, 9])
            self.calculating_unit.prepare_input({CalculatingUnit.KEY_BIT_1: 1, CalculatingUnit.KEY_BIT_2: 0,
                                                 CalculatingUnit.KEY_CARRYOVER: 0})
            result: Dict[int, int] = self.calculating_unit.read_output()
            print(str(result))


if __name__ == '__main__':
    BinaryCalculator(BinaryCalculator.MODE_ADDITION)
