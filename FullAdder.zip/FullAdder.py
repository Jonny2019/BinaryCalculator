from typing import List, Dict

from CalculatingUnit import CalculatingUnit
from tools import overrides


class FullAdder(CalculatingUnit):

    def __init__(self, ports: List[int]):
        self.ports = ports

    @overrides(CalculatingUnit)
    def prepare_input(self, params: Dict[int, int]) -> bool:
        print("input has been prepared with params " + str(params))
        return True

    @overrides(CalculatingUnit)
    def read_output(self) -> Dict[int, int]:
        print("output has been read")
        return {CalculatingUnit.KEY_RESULT: 1, CalculatingUnit.KEY_CARRYOVER: 0}
