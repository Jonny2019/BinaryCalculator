from typing import Dict, Final


class CalculatingUnit(object):
    KEY_RESULT: Final[int] = 0
    KEY_CARRYOVER: Final[int] = 1
    KEY_BIT_1: Final[int] = 2
    KEY_BIT_2: Final[int] = 3

    def prepare_input(self, params: Dict[int, int]) -> bool:
        pass

    def read_output(self) -> Dict[int, int]:
        pass
